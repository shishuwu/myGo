# gopls FAQ

## Why is it called gopls?

Since gopls works both as a language server and as a command line tool, we wanted a name that could be used as a verb. For example, gopls check should read as "go please check." See: [cl/158197].

[cl/158197]: https://golang.org/cl/158197
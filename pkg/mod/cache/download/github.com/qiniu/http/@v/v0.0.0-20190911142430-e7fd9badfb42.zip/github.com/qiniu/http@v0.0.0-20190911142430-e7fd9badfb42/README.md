github.com/qiniu/http
===============

[![Build Status](https://travis-ci.org/qiniu/http.svg?branch=master)](https://travis-ci.org/qiniu/http) [![GoDoc](https://godoc.org/github.com/qiniu/http?status.svg)](https://godoc.org/github.com/qiniu/http)

[![Qiniu Logo](http://open.qiniudn.com/logo.png)](http://www.qiniu.com/)

# 使用文档

* https://godoc.org/github.com/qiniu/http


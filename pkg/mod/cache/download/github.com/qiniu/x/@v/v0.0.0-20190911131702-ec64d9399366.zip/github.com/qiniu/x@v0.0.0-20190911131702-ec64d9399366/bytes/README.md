qiniupkg.com/x/bytes.v7
=====

Extension module of golang bytes processing

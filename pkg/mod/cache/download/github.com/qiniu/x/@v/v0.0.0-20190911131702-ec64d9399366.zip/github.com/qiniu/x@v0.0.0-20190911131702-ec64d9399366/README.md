github.com/qiniu/x
===============

[![Build Status](https://travis-ci.org/qiniu/x.svg?branch=master)](https://travis-ci.org/qiniu/x) [![GoDoc](https://godoc.org/github.com/qiniu/x?status.svg)](https://godoc.org/github.com/qiniu/x)

[![Qiniu Logo](http://open.qiniudn.com/logo.png)](http://www.qiniu.com/)

# 下载

```
go get github.com/qiniu/x
```

# 使用文档

* https://godoc.org/github.com/qiniu/x

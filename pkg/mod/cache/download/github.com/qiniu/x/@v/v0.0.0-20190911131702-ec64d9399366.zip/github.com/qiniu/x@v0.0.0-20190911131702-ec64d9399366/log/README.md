log
===

Extension module of golang logging
package dyn

import (
	_ "github.com/qiniu/dyn/proto"
)
